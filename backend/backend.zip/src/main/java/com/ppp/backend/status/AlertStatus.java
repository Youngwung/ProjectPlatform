package com.ppp.backend.status;

public enum AlertStatus {
    초대,
    접수,
    불합격,
    합격
}