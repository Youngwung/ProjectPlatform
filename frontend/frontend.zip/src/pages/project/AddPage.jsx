import React from 'react'
import AddComponent from '../../components/project/AddComponent'

export default function AddPage() {
	return (
		<div>

			<div>
				<AddComponent />
			</div>
		</div>
	)
}
