package com.ppp.backend.status;

public enum ProjectStatus {
	모집_중,
	진행_중,
	완료
}
